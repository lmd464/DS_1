
public class SortedArrayList<T extends Comparable<T>> implements List<T> {
	
	
	private static final int DEFAULT_MAX_SIZE = 20;
	private int _maxSize;
	private int _size;
	private T[] _element;
	
	
	
	// 생성자
	@SuppressWarnings("unchecked")
	public SortedArrayList() {
		this._maxSize = DEFAULT_MAX_SIZE;
		this._size = 0;
		this._element = (T[])new Comparable[this._maxSize];
	}
	
	
	
	@SuppressWarnings("unchecked")
	public SortedArrayList(int givenMaxSize) {
		this._maxSize = givenMaxSize;
		this._size = 0;
		this._element = (T[])new Comparable[this._maxSize];
	}

	
	
	@Override
	public int size() {
		return this._size;
	}

	
	
	@Override
	public boolean contains(T anElement) {
		boolean found = false;
		for(int index = 0; index < this._size; index++) {
			if(this._element[index].compareTo(anElement) == 0) {
				found = true;
			}
		}
		return found;
	}

	
	
	@Override
	public boolean isFull() {
		return this._size == this._maxSize;
	}

	
	
	@Override
	public boolean isEmpty() {
		return this._size == 0;
	}
	
	
	
	@Override
	public boolean add(T anElement) {
		
		if(this.isFull()) {
			return false;
		}
		
		if(this.isEmpty()) {
			this._element[0] = anElement;
			this._size++;
			return true;
		}
		
		else {
			int currentSize = this._size;
			
			// 탐색
			for(int i = 0; i < currentSize; i++) {
				
				// i 번째에 더 큰 수가 있으면, 공간을 만들고 그 이전에 삽입
				if(this._element[i].compareTo(anElement) >= 0) {	
					
					// 끝부터 한 칸씩 당김
					for(int shiftIndex = this._size - 1; shiftIndex >= i; shiftIndex--) {
						this._element[shiftIndex + 1] = this._element[shiftIndex];
					}
					
					this._element[i] = anElement;
					this._size++;
					return true;
					
				}
				
			}
			
			// 리스트에서 더 큰 수를 찾지 못하면, 맨 끝에다가 삽입
			this._element[this._size] = anElement;
			this._size++;
			return true;
		}
		
	}
	
	
	
	@Override
	public T removeFrom(int aPosition) {
		if(this.isEmpty()) {
			return null;
		} 
		else {
			if(aPosition < 0 || aPosition >= this._size) {
				return null;
			}
			else {
				T removedElement = this._element[aPosition];
				for(int shiftIndex = aPosition; shiftIndex < this._size - 1; shiftIndex++) {
					this._element[shiftIndex] = this._element[shiftIndex + 1];
				}
				this._element[this._size - 1] = null;
				this._size--;
				return removedElement;
			}
		}
	}
	
	
	
	@Override
	public T removeMin() {
		int minPosition = 0;
		for(int i = 1; i < this._size; i++) {
			if( this._element[i].compareTo(this._element[minPosition]) < 0 )
				minPosition = i;
		}
		
		T removedElement = this.removeFrom(minPosition);
		return removedElement;
	}



	@Override
	public T removeMax() {
		int maxPosition = 0;
		for(int i = 1; i < this._size; i++) {
			if( this._element[i].compareTo(this._element[maxPosition]) > 0 )
				maxPosition = i;
		}
		
		T removedElement = this.removeFrom(maxPosition);
		return removedElement;
	}

	

	@Override
	public void clear() {
		this._size = 0;
		for(int i = 0; i < this._maxSize; i++) {
			this._element[i] = null;
		}
	}

	
	
	public T elementAt(int anOrder) {
		if(anOrder < 0 || anOrder >= this._size) {
			return null;
		}
		else {
			return this._element[anOrder];
		}
	}
	
	
	
	
	
	// Iterator
	
	public ListIterator<T> listIterator() {
		return new ListIterator();
	}
	
	
	public class ListIterator<T> implements Iterator<T> {
		
		private int _nextPosition;
		
		
		private ListIterator() {
			this._nextPosition = 0;
		}
		
		
		public boolean hasNext() {
			return ( this._nextPosition < SortedArrayList.this.size() );
		}
		
		
		// next에 들은 값 반환하면서 next 이동
		@SuppressWarnings("unchecked")
		public T next() {
			if(this._nextPosition == SortedArrayList.this.size()) {
				return null;
			}
			else {
				T element = (T)SortedArrayList.this._element[this._nextPosition];
				this._nextPosition++;
				return element;
			}
		}
		
	}
	
	
	
	
	
}
